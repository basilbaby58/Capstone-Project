package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class capStoneProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(capStoneProductApplication.class, args);
	}

}
