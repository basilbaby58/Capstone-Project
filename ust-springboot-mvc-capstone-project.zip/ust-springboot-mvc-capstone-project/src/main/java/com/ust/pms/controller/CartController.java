package com.ust.pms.controller;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Mail;
import com.ust.pms.model.Product;
import com.ust.pms.service.CartService;
import com.ust.pms.service.EmailService;
import com.ust.pms.service.ProductService;

@Controller
public class CartController {

	@Autowired
	private CartService cartService;

	@Autowired
	private ProductService productService;
	
	@Autowired
    private EmailService emailService;

	@RequestMapping("/cart/{pId}")
	public ModelAndView addtoCart(@PathVariable("pId") String pId) {
		ModelAndView view = new ModelAndView();
		String msg=null;
		int id = Integer.parseInt(pId);
		
		String username = productService.getUsername();
		String name  =productService.getName();

		List<Cart> carts = cartService.getProductsFromCart(username);		
		Product product =productService.getProducts(id);
		if(product.getProductQuantity() <= 0 ) {
			msg = product.getProductName()+" not available";
			List<Product> products = productService.getAllProduct();
			view.addObject("msg",msg);
			view.addObject("products",products);
			view.addObject("username",name);
			view.addObject("cartCount",carts.size());
			view.setViewName("Home");
			return view;
		}
	
		if(carts.size() >= 10) {
			
				try {
					emailService.sendmail(new Mail(username, "Your cart is full, maximum cart amount is 10"));
				} catch (AddressException e) {
					
					e.printStackTrace();
				} catch (MessagingException e) {
					
					e.printStackTrace();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			
			msg = "Your cart is full";
			List<Product> products = productService.getAllProduct();
			view.addObject("msg",msg);
			view.addObject("products",products);
			view.addObject("username",username);
			view.addObject("cartCount",carts.size());
			view.setViewName("Home");
			return view;
		}
		
		cartService.updateProductFromCart(username, id);
		List<Cart> cartsData = cartService.getProductsFromCart(username);		
		List<Product> products = productService.getAllProduct();
		msg =  product.getProductName()+" successfully added to cart";
		view.addObject("msg",msg);
		view.addObject("products",products);
		view.addObject("username",username);
		view.addObject("cartCount",cartsData.size());
		view.setViewName("Home");
		return view;

	}
	
	@GetMapping("/cart")
	public ModelAndView getCart() {
		String username = productService.getUsername();
		String name  =productService.getName();
		
		int totalPrice = 0;
		ModelAndView view = new ModelAndView();
		
		List<Cart> carts = cartService.getProductsFromCart(username);
		if(carts.size() == 0) {
			try {
				emailService.sendmail(new Mail(username, "Your cart is empty, please add your products"));
			} catch (AddressException e) {
				
				e.printStackTrace();
			} catch (MessagingException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			List<Product> products = productService.getAllProduct();
			view.addObject("msg","Cart is empty");
			view.addObject("products",products);
			view.addObject("username",name);
			view.addObject("cartCount",carts.size());
			view.setViewName("Home");
			return view;
		}
		
		totalPrice = cartService.getTotalPrice(carts);
		
		view.addObject("username",name);
		view.addObject("carts",carts);
		view.addObject("cartproductTotalPrice",totalPrice);
		view.setViewName("cart");
		return view;
	}
	
	@RequestMapping("/cartDelete/{cId}")
	public ModelAndView deleteFromCart(@PathVariable("cId") String cId) {
		String username = productService.getUsername();
		String name  =productService.getName();
		int totalPrice = 0;
		
		int id = Integer.parseInt(cId);
		Cart cart = cartService.getCarts(id);
		String cartedProductName = cart.getProductName();
		cartService.deleteProductFromCart(id);
		
		ModelAndView view = new ModelAndView();
		view.addObject("username",name);
		
		List<Cart> carts = cartService.getProductsFromCart(username);
		totalPrice = cartService.getTotalPrice(carts);
		if(carts.size() == 0) {
			List<Product> products = productService.getAllProduct();
			view.addObject("cartCount",carts.size());
			view.addObject("msg","You removed "+cartedProductName+" from cart");
			view.addObject("products",products);
			view.setViewName("Home");
			return view;
		}
	
		view.addObject("cartproductTotalPrice",totalPrice);
		view.addObject("msg",cartedProductName+" removed from cart");
		
		view.addObject("carts",carts);
		view.setViewName("cart");
		return view;
		
	}
	
	@RequestMapping("/cartBuy/{cId}")
	public ModelAndView buyFromCart(@PathVariable("cId") String cId) {
		String username = productService.getUsername();
		String name  =productService.getName();
		int totalPrice = 0;
		
		int id = Integer.parseInt(cId);
		Cart cart = cartService.getCarts(id);
		String cartedProductName = cart.getProductName();
	    cartService.deleteCart(id);
	    ModelAndView view = new ModelAndView();
		view.addObject("username",name);
		
		List<Cart> carts = cartService.getProductsFromCart(username);
		totalPrice = cartService.getTotalPrice(carts);
		if(carts.size() == 0) {
			List<Product> products = productService.getAllProduct();
			view.addObject("cartCount",carts.size());
			view.addObject("msg","You successfully bought "+cartedProductName);
			view.addObject("products",products);
			view.setViewName("Home");
			return view;
		}
		view.addObject("msg","You successfully bought "+cartedProductName);
		view.addObject("cartproductTotalPrice",totalPrice);
		view.addObject("carts",carts);
		view.setViewName("cart");
		return view;
		
	}
	
	@RequestMapping("/cartBuy/")
	public ModelAndView buyFromCartAll() {
		String username = productService.getUsername();
		String name  =productService.getName();
		
		List<Cart> carts = cartService.getProductsFromCart(username);
		cartService.deleteCart(carts);
	
		List<Cart> cartsData = cartService.getProductsFromCart(username);		
		List<Product> products = productService.getAllProduct();
		
		ModelAndView view = new ModelAndView();
		view.addObject("products",products);
		view.addObject("msg","All products are placed");
		view.addObject("username",name);
		view.addObject("cartCount",cartsData.size());
		view.setViewName("Home");
		return view;
	}
}
