package com.ust.pms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Mail;
import com.ust.pms.model.UserRegistration;
import com.ust.pms.service.CartService;
import com.ust.pms.service.EmailService;

@Controller
public class LoginController {
	
	@Autowired
    private EmailService emailService;
	
	@Autowired 
	CartService cartService;
	
	@Autowired
	JdbcUserDetailsManager jdbcUserDetailsManager;
	
	
	@GetMapping("/login")
	public ModelAndView login(Model model,String error,String logout) {
		ModelAndView view = new ModelAndView();
		if(error != null)
		view.addObject("emsg", "Your username or password are incorrect");
		if(logout != null)
		view.addObject("msg", "You have been successfully logged out"); 
		view.addObject("user",new UserRegistration());
		view.setViewName("login");
		return view;
	}
	
	@GetMapping("/register")
	public ModelAndView register() {
		return new ModelAndView("registration","user",new UserRegistration());
	}
	
	
	@PostMapping("/register")
	public ModelAndView userRegister(@ModelAttribute("user") UserRegistration userRegistration) {
		
		if(!cartService.getUsersData(userRegistration.getUsername())){
			return new ModelAndView("login","msg","User already existing");
		}
		
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
		
		User user = new User(userRegistration.getUsername(), userRegistration.getPassword(), authorities);
		try {
			emailService.sendmail(new Mail(userRegistration.getUsername(), "Welcome to CapStone Shopping World"));
		} catch (AddressException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		jdbcUserDetailsManager.createUser(user);
		return new ModelAndView("login","msg","You have been successfully registred");
	}
	
	@GetMapping("/forgot")
	public ModelAndView forgot() {
		return new ModelAndView("forgot","user",new UserRegistration());
	}
	
	@PostMapping("/forgot")
	public ModelAndView userForgot(@ModelAttribute("user") UserRegistration userRegistration) {
		
		try {
			emailService.sendmail(new Mail(userRegistration.getUsername(), "Your CapStone password is "+cartService.getPassword(userRegistration.getUsername())));
		} catch (AddressException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ModelAndView("login","msg"," Please check your mail");
	}

}
