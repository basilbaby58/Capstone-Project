package com.ust.pms.controller;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Mail;
import com.ust.pms.model.Product;
import com.ust.pms.service.CartService;
import com.ust.pms.service.EmailService;
import com.ust.pms.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;
	
	@Autowired
	CartService cartService;
	

	@Autowired
    private EmailService emailService;

   
	
	@RequestMapping("/")
	public ModelAndView index() {
		String username = productService.getUsername();
		String name  =productService.getName();
		
		List<Product> products = productService.getAllProduct();
		List<Cart> carts = cartService.getProductsFromCart(username);
		ModelAndView view = new ModelAndView();
		view.addObject("username",name);
		view.addObject("products",products);
		view.addObject("cartCount",carts.size());
		if(username.equalsIgnoreCase("admin@gmail.com")) {
			view.setViewName("adminHome");
		}else {
			if(carts.size() == 0 ) {
				try {
					emailService.sendmail(new Mail(username,  "Your cart is empty, please view our products"));
				} catch (AddressException e) {
					
					e.printStackTrace();
				} catch (MessagingException e) {
					
					e.printStackTrace();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		view.setViewName("Home");
		}
		return view;
	}


	@RequestMapping("/addProduct")
	public ModelAndView addProduct() {
		String name  =productService.getName();
		
		ModelAndView view = new ModelAndView();
		view.addObject("product",new Product());
		view.addObject("username",name);
		view.setViewName("addProduct");
		return view;
	}

	@PostMapping("/saveProduct")
	public ModelAndView saveProduct(@ModelAttribute Product product) {
		String name  =productService.getName();
		
		 List<Product> productData = productService.getAllProduct();
		ModelAndView view = new ModelAndView();
		view.addObject("username",name);
		view.setViewName("adminHome");
		for (Product products : productData) {
			if(products.getProductName().equalsIgnoreCase(product.getProductName()) ) {
				view.addObject("products",productData); 
				view.addObject("msg",product.getProductName()+" already existing");
				return view;
			}
		}
		productService.saveProduct(product);
		productData = productService.getAllProduct();
		view.addObject("products",productData); 
		view.addObject("msg",product.getProductName()+" added successfully");
		return view;
	}
	
	@RequestMapping("/updateProduct/{pId}")
	public ModelAndView updateProduct(@PathVariable("pId") String pId) {
		int id = Integer.parseInt(pId);
		String name  =productService.getName();
		Product product = productService.getProducts(id);
		ModelAndView view = new ModelAndView();
		view.addObject("product",product);
		view.addObject("username",name);
		view.setViewName("updateProduct");
		return view;
	}
	
	@RequestMapping("/updateProduct")
	public ModelAndView updateProductData(@ModelAttribute Product product) {
		ModelAndView view = new ModelAndView();
		
		String name  =productService.getName();
		
		view.addObject("username",name);
		view.setViewName("adminHome");
		List<Product> products = productService.findProdutcsExeptId(product.getProductId());
		List<Product> productsData =  productService.getAllProduct();
		for (Product productData : products) {
			if(productData.getProductName().equalsIgnoreCase(product.getProductName())) {
				view.addObject("products",productsData);
				view.addObject("msg",product.getProductName()+" already existing");
				return view;
			}
		}
		
		productService.updateProduct(product);
		List<Cart> carts = cartService.findCartByProductId(product.getProductId());
		for(Cart cart :carts) {
			cart.setProductName(product.getProductName());
			cart.setProductTotalPrice(product.getProductPrice()*cart.getProductQuantity());
			cartService.updateCart(cart);
		}
		products = productService.getAllProduct();
		view.addObject("products",products);
		view.addObject("msg","Product updated successfully");
		return view;
	}

	

	@RequestMapping("/deleteProductById/{pId}")
	public ModelAndView deleteProductById(@PathVariable("pId") String pId) {
		String name  =productService.getName();
		ModelAndView view = new ModelAndView();
		int id = Integer.parseInt(pId);

		Product product = productService.getProducts(id);
		if(productService.isProductExists(id)) {
			productService.deleteProduct(id);
			view.addObject("msg",product.getProductName()+" deleted successfully");
		}else {
			view.addObject("msg",product.getProductName()+" does not exist");
		}
		List<Cart> carts = cartService.findCartByProductId(id);
		cartService.deleteCart(carts);
		List<Product> products = productService.getAllProduct();
		view.addObject("username",name);
		view.addObject("products",products);
		view.setViewName("adminHome"); 
		return view;
	}

	@RequestMapping("/viewAllProducts")
	public ModelAndView viewAllProducts() {
		List<Product> products = productService.getAllProduct();
		return new ModelAndView("viewAllProducts","products",products);
	}

	

}
