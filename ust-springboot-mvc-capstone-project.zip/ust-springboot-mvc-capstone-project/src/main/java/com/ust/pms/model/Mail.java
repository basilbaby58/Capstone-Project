package com.ust.pms.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Mail {
	private String maiId;
	private String emailMsg;
	
}
