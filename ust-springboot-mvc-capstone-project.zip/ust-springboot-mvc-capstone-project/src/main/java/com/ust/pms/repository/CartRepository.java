package com.ust.pms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ust.pms.model.Cart;

public interface CartRepository extends CrudRepository<Cart, Integer>{
	
	@Query(value= "select *  from cart c where c.username = ?1 and c.product_id = ?2",nativeQuery = true)
	public Cart findCartByUsernameAndProductId(String username,int productId);
	
	@Query(value= "select * from cart c where c.username = ?1",nativeQuery = true)
	public List<Cart> findCartByUsername(String username);
	
	
	@Query(value= "select * from cart c where c.product_id = ?1",nativeQuery = true)
	public List<Cart> findCartByProductId(int productId);
	
	@Query(value= "select password from users u where u.username= ?1",nativeQuery = true)
	public String findPwd(String username);
	
	@Query(value= "select username from users u where u.username= ?1",nativeQuery = true)
	public String getUserData(String username);
	
	
}
