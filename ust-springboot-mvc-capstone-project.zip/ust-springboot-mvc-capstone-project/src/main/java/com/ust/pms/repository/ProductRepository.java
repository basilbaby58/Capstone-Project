package com.ust.pms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ust.pms.model.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{
	
	@Query(value= "select * from product p where p.product_id != ?1",nativeQuery = true)
	public List<Product> findProdutcsExeptId(int productId);
	
}
