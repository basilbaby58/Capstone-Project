package com.ust.pms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;
import com.ust.pms.repository.CartRepository;

@Service
public class CartService {

	@Autowired
	CartRepository cartRepository;

	@Autowired
	ProductService productService;

	public Cart saveCart(Cart cart) {
		Cart cartData = cartRepository.save(cart);
		return cartData;
	}

	public List<Cart> getAllCart() {
		return (List<Cart>) cartRepository.findAll();
	}

	public Cart getCarts(Integer id) {
		Optional<Cart> cart = cartRepository.findById(id);
		return cart.get();
	}

	public boolean deleteCart(Integer id) {
		cartRepository.deleteById(id);
		return true;
	}

	public boolean updateCart(Cart cart) {
		cartRepository.save(cart);
		return true;
	}

	public boolean isProductExists(int productId) {
		return cartRepository.existsById(productId);

	}

	public Cart getProductFromCart(String username,int prodductId) {
		return cartRepository.findCartByUsernameAndProductId(username, prodductId);
	}

	public List<Cart> getProductsFromCart(String username) {
		return cartRepository.findCartByUsername(username);
	}
	public List<Cart> findCartByProductId(int productId){
		return cartRepository.findCartByProductId(productId);
	}

	public String getPassword(String username) {
		return cartRepository.findPwd(username);
	}

	public boolean getUsersData(String username) {
		String userData = cartRepository.getUserData(username);
		if(userData == null)
			return true;
		else
			return false;
	}

	public boolean updateProductFromCart(String username, int id) {
		Product product =productService.getProducts(id);
		Cart cartData = this.getProductFromCart(username, id);
		if(cartData == null) {
			Cart cart = new Cart();
			cart.setProductId(id);
			cart.setProductQuantity(1);
			cart.setProductName(product.getProductName());
			cart.setUsername(username);
			cart.setProductTotalPrice(product.getProductPrice());
			this.saveCart(cart);

			int pQuantity = product.getProductQuantity();
			product.setProductQuantity(pQuantity-1);
			productService.updateProduct(product);
		}else {
			int quantity =  cartData.getProductQuantity();
			cartData.setProductQuantity(quantity+1);
			cartData.setProductTotalPrice(cartData.getProductQuantity()*product.getProductPrice());
			this.updateCart(cartData);

			int pQuantity = product.getProductQuantity();
			product.setProductQuantity(pQuantity-1);
			productService.updateProduct(product);
		}
		return true;

	}

	public boolean deleteProductFromCart(int id) {
		Cart cart = this.getCarts(id);
		Product product = productService.getProducts(cart.getProductId());
		if(cart.getProductQuantity() == 1) {
			this.deleteCart(id);
			product.setProductQuantity(product.getProductQuantity()+1);
			productService.updateProduct(product);
		}else {
			cart.setProductQuantity(cart.getProductQuantity()-1);
			cart.setProductTotalPrice(cart.getProductQuantity()*product.getProductPrice());
			this.updateCart(cart);
			product.setProductQuantity(product.getProductQuantity()+1);
			productService.updateProduct(product);
		}
		return true;
	}

	public int getTotalPrice(List<Cart> carts) {
		int totalPrice = 0;
		for (Cart cartPro : carts) {
			totalPrice =totalPrice+cartPro.getProductTotalPrice();
		}
		return totalPrice;
	}

	public boolean deleteCart(List<Cart> carts) {
		for (Cart cartPro : carts) {
			this.deleteCart(cartPro.getCartId());
		}
		return true;
	}

}
