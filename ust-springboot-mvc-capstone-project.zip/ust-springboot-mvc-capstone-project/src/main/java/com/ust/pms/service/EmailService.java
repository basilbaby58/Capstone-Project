package com.ust.pms.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.ust.pms.model.Mail;

@Service
public class EmailService {

	@Value("${email.username}")
	private String username;

	@Value("${email.password}")
	private String password;

	@Autowired
	private SpringTemplateEngine templateEngine;

	public void sendmail(Mail mail) throws AddressException, MessagingException, IOException {

		int subStringLength = mail.getMaiId().indexOf("@");
		String name  = mail.getMaiId().substring(0, subStringLength);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("name", name);
		model.put("msg",mail.getEmailMsg());
		model.put("sign","CapStone pvt ltd");
		model.put("location","Kochi");
		
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username,password);
			}
		});
		
		MimeMessage msg = new MimeMessage(session);
		MimeMessageHelper helper = new MimeMessageHelper(msg,
				MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
				StandardCharsets.UTF_8.name());
		
		Context context = new Context();
		context.setVariables(model);	  

		String html = templateEngine.process("email-template", context);
		helper.setTo(mail.getMaiId());
		helper.setText(html, true);
		helper.setSubject("CapStone Notification");
		helper.setFrom(username);
		Transport.send(msg);   
		
	}
}
