package com.ust.pms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;
import com.ust.pms.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	public Product saveProduct(Product product) {
		Product productData = productRepository.save(product);
		return productData;
	}
	
	public List<Product> getAllProduct() {
		return (List<Product>) productRepository.findAll();
	}

	public Product getProducts(Integer id) {
		Optional<Product> product = productRepository.findById(id);
		return product.get(); // searching based on id from all data
	}
	
	public boolean deleteProduct(Integer id) {
		productRepository.deleteById(id);
		return true;
	}
	
	public boolean updateProduct(Product product) {
		productRepository.save(product);
		return true;
	}
	

	public boolean isProductExists(int productId) {
		return productRepository.existsById(productId);
		
	}
	
	public List<Product> findProdutcsExeptId(int productId){
		List<Product> productList = productRepository.findProdutcsExeptId(productId);
		return productList;
	}
	
	 public String getUsername() {
		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		}
		return username;
	
	 }
	 
	 public String getName() {
			String username = null;
			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if(principal instanceof UserDetails) {
				username = ((UserDetails) principal).getUsername();
			}
			int subStringLength = username.indexOf("@");
			String name  =username.substring(0, subStringLength);
		return name;
		 }
}
