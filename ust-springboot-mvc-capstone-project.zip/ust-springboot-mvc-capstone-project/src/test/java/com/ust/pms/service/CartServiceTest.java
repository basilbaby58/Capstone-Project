package com.ust.pms.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.pms.model.Cart;

@SpringBootTest
class CartServiceTest {

	@Autowired 
	CartService cartService;

	@BeforeEach
	
	public void setUp()  {
	
	}

	@AfterEach
	void tearDown() throws Exception {
	}
	
	@Test
	void testSaveCart() {
		Cart cart = new Cart(10001, "testuser", 10001, "cartproduct", 1, 1);
		cart = cartService.saveCart(cart);
		int cId = cart.getCartId();
		cartService.deleteCart(cId);
		assertEquals("cartproduct", cart.getProductName());
	}

	@Test
	void testGetAllCart() {
		List<Cart> carts = cartService.getAllCart();
		assertTrue(carts.size() > 0);
	}

	@Test
	void testGetCarts() {
		Cart cart = new Cart(10001, "testuser", 10001, "cartproduct", 1, 1);
		cart = cartService.saveCart(cart);
		int cId = cart.getCartId();
		cart = cartService.getCarts(cId);
		cartService.deleteCart(cId);
		assertEquals("cartproduct", cart.getProductName());
	}

	@Test
	void testUpdateCart() {
		boolean result = false;
		Cart cart = new Cart(10001, "testuser", 10001, "cartproduct", 1, 1);
		cart = cartService.saveCart(cart);
		int cId = cart.getCartId();
		cart = new Cart(cId, "testuser1", 10001, "cartproduct1", 1, 1);
		result = cartService.updateCart(cart);
		cartService.deleteCart(cId);
		assertEquals(true, result);
	}

	@Test
	void testGetProductsFromCart() {
		Cart cart = new Cart(10001, "testuser", 10001, "cartproduct", 1, 1);
		cart = cartService.saveCart(cart);
		int cId = cart.getCartId();
		List<Cart> carts = cartService.getProductsFromCart("testuser");
		cartService.deleteCart(cId);
		assertTrue(carts.size() > 0);
	}

	
	@Test
	void testDeleteCart() {
		boolean result = false;
		Cart cart = new Cart(10001, "testuser", 10001, "cartproduct", 1, 1);
		cart = cartService.saveCart(cart);
		int cId = cart.getCartId();
		result = cartService.deleteCart(cId);
		assertEquals(true, result);
	}

}
