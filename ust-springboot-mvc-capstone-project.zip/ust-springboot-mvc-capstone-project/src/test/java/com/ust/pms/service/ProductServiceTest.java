package com.ust.pms.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.pms.model.Product;
@SpringBootTest
public class ProductServiceTest {

	@Autowired 
	ProductService productService;

	@BeforeEach
	public void setUp()  {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	
	@Test
	public void testSaveProduct() {
		Product product = new Product(10002,"product",5,10);
		product = productService.saveProduct(product);
		int pId = product.getProductId();
		productService.deleteProduct(pId);
		assertEquals("product", product.getProductName());
	}


	@Test
	void testGetAllProduct() {
		List<Product> products = productService.getAllProduct();
		assertTrue(products.size() > 0);
	}

	@Test
	void testGetProducts() {
		Product product = new Product(10002,"product",5,10);
		product = productService.saveProduct(product);
		int pId = product.getProductId();
		product = productService.getProducts(pId);
		productService.deleteProduct(pId);
		assertEquals("product", product.getProductName());
	}

	@Test
	void testIsProductExists() {
		boolean result = false;
		Product product = new Product(10002,"product",15,100);
		product = productService.saveProduct(product);
		int pId = product.getProductId();
		result = productService.isProductExists(pId);
		productService.deleteProduct(pId);
		assertEquals(true, result);
	}

	@Test
	void testUpdateProduct() {
		boolean result = false;
		Product product = new Product(10002,"product",15,100);
		product = productService.saveProduct(product);
		int pId = product.getProductId();
		product = new Product(pId,"product1",15,100);
		result = productService.updateProduct(product);
		productService.deleteProduct(pId);
		assertEquals(true, result);
	}

	@Test
	void testDeleteProduct() {
		boolean result = false;
		Product product = new Product(10002,"product",15,100);
		product = productService.saveProduct(product);
		int pId = product.getProductId();
		result = productService.deleteProduct(pId);
		assertEquals(true, result);
	}

}
